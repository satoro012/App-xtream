# MeuIPTV

Cliente IPTV para servidores Xtream Codes, construído do zero em HTML5, CSS3 e JavaScript puro, empacotado como APK Android com **Capacitor**. Nenhum código de XCIPTV, IBO Player ou apps similares foi usado.

Funciona apenas com servidores/listas que **você tem autorização para usar**. O app não vem com nenhuma conta ou servidor pré-configurado.

## Estrutura do projeto

```
MeuIPTV/
├── .github/workflows/build-apk.yml   # compila o APK na nuvem (GitHub Actions)
├── android/                          # gerado automaticamente pelo Capacitor
├── www/
│   ├── index.html
│   ├── css/style.css
│   └── js/
│       ├── storage.js      # credenciais e favoritos salvos no aparelho
│       ├── api.js          # chamadas à API Xtream Codes (player_api.php)
│       ├── player.js       # player de vídeo (HTML5 + hls.js)
│       ├── app.js          # login, navegação, telas
│       └── vendor/hls.min.js   # você baixa este arquivo (passo 4)
├── capacitor.config.json
├── package.json
└── README.md
```

## O que cada parte faz

- **`www/index.html`** — todas as telas do app (login, canais, filmes, séries, detalhe de série, ajustes, player).
- **`www/css/style.css`** — tema escuro, cards, navegação inferior, player.
- **`www/js/storage.js`** — guarda servidor/usuário/senha e favoritos só no `localStorage` do aparelho. Nada sai do celular.
- **`www/js/api.js`** — monta as URLs do `player_api.php` (login, categorias, listas, episódios) e as URLs de reprodução (`/live/`, `/movie/`, `/series/`).
- **`www/js/player.js`** — toca o vídeo. Streams `.m3u8` usam a biblioteca `hls.js`; `.mp4` tocam direto no `<video>`.
- **`www/js/app.js`** — liga tudo: login, abas (Canais/Filmes/Séries/Favoritos/Ajustes), categorias, pesquisa global, favoritos, tela de série com temporadas/episódios.

## Antes de baixar qualquer coisa: tamanhos aproximados

| Item | Tamanho aprox. | Necessário? |
|---|---|---|
| Node.js + Git + OpenJDK 17 (pacotes Termux) | ~250 MB | Sim, sempre |
| `hls.min.js` | ~250 KB | Sim, para canais ao vivo |
| Dependências npm (`@capacitor/*`) | ~30 MB | Sim, sempre |
| Projeto Android gerado (`npx cap add android`) + Gradle Wrapper | ~200–300 MB | Sim, sempre |
| Android SDK completo (só se for compilar **local** no Termux) | ~800 MB–1,5 GB | **Só** se escolher o Caminho A abaixo |

Por isso, o **Caminho B (GitHub Actions)** é o recomendado para quem só tem o celular: o SDK Android pesado fica no servidor do GitHub, não no seu aparelho.

---

## Passo 1 — Instalar o Termux e pacotes base

No Termux (F-Droid, não use a versão da Play Store, que está desatualizada):

```bash
pkg update -y && pkg upgrade -y
pkg install -y nodejs-lts git openjdk-17 wget unzip
```

## Passo 2 — Criar as pastas e colocar os arquivos

```bash
mkdir -p ~/MeuIPTV/www/css ~/MeuIPTV/www/js/vendor
cd ~/MeuIPTV
```

Copie o conteúdo de cada arquivo entregue acima para o caminho correspondente:

- `www/index.html`
- `www/css/style.css`
- `www/js/storage.js`
- `www/js/api.js`
- `www/js/player.js`
- `www/js/app.js`
- `capacitor.config.json`
- `package.json`
- `.github/workflows/build-apk.yml` (crie a pasta `.github/workflows/` primeiro)

Você pode usar um editor de texto do Termux (`nano arquivo`) ou um app de edição de código no Android e salvar direto nesses caminhos.

## Passo 3 — Instalar as dependências do projeto

```bash
cd ~/MeuIPTV
npm install
```

## Passo 4 — Baixar o hls.js (necessário para tocar canais ao vivo em .m3u8)

```bash
wget -O www/js/vendor/hls.min.js https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js
```

## Passo 5 — Testar a interface rapidamente (sem gerar APK ainda)

Você pode abrir `www/index.html` num navegador do celular (Chrome) para conferir visualmente o login e o layout. A leitura de arquivos locais é limitada pelo navegador, então o teste completo com API só funciona de fato dentro do app (Passo 7 em diante) ou publicando a pasta `www` num servidor local:

```bash
cd ~/MeuIPTV/www
python3 -m http.server 8080 2>/dev/null || (pkg install -y python && python -m http.server 8080)
# depois acesse http://localhost:8080 no navegador do celular
```

## Passo 6 — Criar o projeto Android com o Capacitor

```bash
cd ~/MeuIPTV
npx cap add android
npx cap sync android
```

Isso cria a pasta `android/` com o Gradle Wrapper (baixa ~200–300 MB na primeira sincronização).

---

## Passo 7 — Gerar o APK (escolha um caminho)

### Caminho A — Build 100% local no Termux (mais pesado, mais frágil)

Requer instalar o Android SDK manualmente, pois não existe Android Studio no Termux:

```bash
cd ~
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-11076708_latest.zip -d android-sdk/cmdline-tools
mv android-sdk/cmdline-tools/cmdline-tools android-sdk/cmdline-tools/latest
export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

echo "sdk.dir=$HOME/android-sdk" > ~/MeuIPTV/android/local.properties

cd ~/MeuIPTV/android
chmod +x gradlew
./gradlew assembleDebug
```

**Aviso honesto:** compilar Android nativamente dentro do Termux costuma esbarrar em incompatibilidades de arquitetura (ex.: `aapt2`) dependendo da versão do Gradle/Android Gradle Plugin e do seu Android. Se `./gradlew assembleDebug` falhar com erro de `aapt2` ou binário incompatível, use o Caminho B.

### Caminho B — Build na nuvem via GitHub Actions (recomendado pelo celular)

1. Crie uma conta gratuita em github.com (pelo navegador do celular).
2. No Termux, envie o projeto para um repositório novo:
   ```bash
   cd ~/MeuIPTV
   git init
   git add .
   git commit -m "MeuIPTV v1"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/meuiptv.git
   git push -u origin main
   ```
3. O arquivo `.github/workflows/build-apk.yml` já entregue dispara a compilação automaticamente a cada `push`, ou manualmente na aba **Actions → Build APK → Run workflow** no site do GitHub.
4. Quando o workflow terminar (ícone verde ✅), abra a execução e baixe o artefato **MeuIPTV-debug-apk** — é o seu `app-debug.apk`.

---

## Onde fica o APK gerado

- Caminho A (local): `android/app/build/outputs/apk/debug/app-debug.apk`
- Caminho B (GitHub Actions): dentro do artefato `MeuIPTV-debug-apk` baixado da aba Actions

## Como instalar o APK no Android

1. Copie o `app-debug.apk` para o armazenamento do celular (se veio do GitHub, o navegador já baixa direto).
2. Toque no arquivo pelo gerenciador de arquivos.
3. Se pedir, permita "Instalar apps de fontes desconhecidas" para o navegador/gerenciador de arquivos usado.
4. Confirme a instalação.

## Alterar nome e ícone depois

- **Nome:** troque `appName` em `capacitor.config.json` e rode `npx cap sync android` de novo.
- **Ícone:** substitua as imagens em `android/app/src/main/res/mipmap-*/` (o Capacitor tem um plugin `@capacitor/assets` que gera todos os tamanhos a partir de uma imagem única, se quiser automatizar depois).

## Próximos passos sugeridos (fora do escopo da v1)

- Player nativo (ExoPlayer via plugin Capacitor em Kotlin) para maior compatibilidade com formatos MPEG-TS em streams ao vivo problemáticas.
- Suporte a EPG (guia de programação).
- Tela dedicada para Android TV (D-pad).
