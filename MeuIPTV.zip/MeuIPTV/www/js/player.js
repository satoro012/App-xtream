/**
 * player.js
 * Player de vídeo do MeuIPTV.
 *
 * Usa o elemento <video> nativo do WebView. Para streams .m3u8 (HLS),
 * que a maioria dos Android WebViews não reproduz nativamente, usa a
 * biblioteca hls.js (arquivo local em www/js/vendor/hls.min.js) para
 * decodificar o stream em JavaScript. Streams .mp4 tocam direto no
 * elemento <video>, sem necessidade de biblioteca extra.
 */

const Player = (() => {
  let video, hls;
  let controlsTimeout;
  let onCloseCallback = null;

  function init() {
    video = document.getElementById('video');
    video.addEventListener('play', () => setPlayPauseIcon(true));
    video.addEventListener('pause', () => setPlayPauseIcon(false));
    video.addEventListener('timeupdate', updateProgress);
    video.addEventListener('loadedmetadata', updateProgress);
    video.addEventListener('waiting', () => showCenterStatus(true));
    video.addEventListener('playing', () => showCenterStatus(false));
    video.addEventListener('error', onVideoError);

    document.getElementById('btn-play-pause').addEventListener('click', togglePlayPause);
    document.getElementById('btn-mute').addEventListener('click', toggleMute);
    document.getElementById('btn-fullscreen').addEventListener('click', toggleFullscreen);
    document.getElementById('btn-player-back').addEventListener('click', close);
    document.getElementById('progress-bar').addEventListener('input', onScrub);

    document.getElementById('player-container').addEventListener('click', (e) => {
      if (e.target.id === 'player-container' || e.target.id === 'video') toggleControls();
    });
  }

  function showCenterStatus(show) {
    document.getElementById('player-center-status').classList.toggle('hidden', !show);
  }

  function setPlayPauseIcon(playing) {
    document.getElementById('btn-play-pause').textContent = playing ? '⏸' : '▶';
  }

  function formatTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    const m = Math.floor(sec / 60).toString().padStart(2, '0');
    const s = Math.floor(sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  function updateProgress() {
    const bar = document.getElementById('progress-bar');
    if (video.duration && isFinite(video.duration)) {
      bar.max = 100;
      bar.value = (video.currentTime / video.duration) * 100;
      document.getElementById('time-duration').textContent = formatTime(video.duration);
    } else {
      // Live stream sem duração conhecida
      bar.value = 0;
      document.getElementById('time-duration').textContent = 'AO VIVO';
    }
    document.getElementById('time-current').textContent = formatTime(video.currentTime);
  }

  function onScrub(e) {
    if (video.duration && isFinite(video.duration)) {
      video.currentTime = (e.target.value / 100) * video.duration;
    }
  }

  function togglePlayPause() {
    if (video.paused) video.play(); else video.pause();
  }

  function toggleMute() {
    video.muted = !video.muted;
    document.getElementById('btn-mute').textContent = video.muted ? '🔇' : '🔊';
  }

  function toggleFullscreen() {
    const container = document.getElementById('player-container');
    if (!document.fullscreenElement) {
      if (container.requestFullscreen) container.requestFullscreen();
      else if (video.webkitEnterFullscreen) video.webkitEnterFullscreen();
      if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('landscape').catch(() => {});
      }
    } else {
      document.exitFullscreen && document.exitFullscreen();
      if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
    }
  }

  function toggleControls() {
    document.getElementById('player-overlay').classList.toggle('hidden-controls');
  }

  function resetAutoHide() {
    clearTimeout(controlsTimeout);
    document.getElementById('player-overlay').classList.remove('hidden-controls');
    controlsTimeout = setTimeout(() => {
      if (!video.paused) document.getElementById('player-overlay').classList.add('hidden-controls');
    }, 4000);
  }

  function onVideoError() {
    showCenterStatus(false);
    const err = document.getElementById('player-error');
    err.textContent = 'Não foi possível reproduzir este conteúdo. Verifique sua conexão ou tente outro item.';
    err.classList.remove('hidden');
  }

  function destroyHls() {
    if (hls) {
      hls.destroy();
      hls = null;
    }
  }

  /**
   * Reproduz uma URL. Detecta automaticamente se deve usar hls.js
   * (streams .m3u8) ou reprodução nativa (.mp4, .ts, etc).
   */
  function play(url, title) {
    document.getElementById('player-title').textContent = title || '';
    document.getElementById('player-error').classList.add('hidden');
    showCenterStatus(true);
    destroyHls();
    video.removeAttribute('src');
    video.load();

    const isHls = url.includes('.m3u8');

    if (isHls && window.Hls && window.Hls.isSupported()) {
      hls = new window.Hls({ enableWorker: true });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(window.Hls.Events.ERROR, (event, data) => {
        if (data.fatal) onVideoError();
      });
      hls.on(window.Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(() => {});
      });
    } else {
      // Reprodução nativa: cobre .mp4/.ts e navegadores com suporte
      // nativo a HLS (ex.: WebKit em iOS, se o projeto for portado).
      video.src = url;
      video.play().catch(() => {});
    }

    resetAutoHide();
    video.onclick = resetAutoHide;
  }

  function open(url, title, onClose) {
    onCloseCallback = onClose || null;
    document.getElementById('player-error').classList.add('hidden');
    play(url, title);
  }

  function close() {
    video.pause();
    destroyHls();
    video.removeAttribute('src');
    video.load();
    if (document.fullscreenElement) document.exitFullscreen();
    if (onCloseCallback) onCloseCallback();
  }

  return { init, open, close };
})();
