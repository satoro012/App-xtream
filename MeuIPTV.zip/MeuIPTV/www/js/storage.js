/**
 * storage.js
 * Camada de armazenamento local do MeuIPTV.
 * Guarda credenciais, favoritos e preferências no localStorage do dispositivo.
 * Nada é enviado para nenhum servidor externo — tudo fica só no aparelho do usuário.
 */

const Storage = (() => {
  const KEYS = {
    ACCOUNT: 'meuiptv_account',
    FAVORITES: 'meuiptv_favorites',
    CACHE: 'meuiptv_cache',
  };

  // Ofuscação simples (Base64) só para não deixar a senha 100% em texto puro
  // no localStorage. Isto NÃO é criptografia forte — é proteção "razoável"
  // para o contexto de um app local, como pedido no briefing.
  function encode(str) {
    try { return btoa(unescape(encodeURIComponent(str))); }
    catch (e) { return str; }
  }
  function decode(str) {
    try { return decodeURIComponent(escape(atob(str))); }
    catch (e) { return str; }
  }

  function saveAccount({ server, username, password }) {
    const data = {
      server: server.trim().replace(/\/+$/, ''),
      username: username.trim(),
      password: encode(password),
    };
    localStorage.setItem(KEYS.ACCOUNT, JSON.stringify(data));
    return data;
  }

  function getAccount() {
    const raw = localStorage.getItem(KEYS.ACCOUNT);
    if (!raw) return null;
    try {
      const data = JSON.parse(raw);
      return {
        server: data.server,
        username: data.username,
        password: decode(data.password),
      };
    } catch (e) {
      return null;
    }
  }

  function clearAccount() {
    localStorage.removeItem(KEYS.ACCOUNT);
  }

  function clearAll() {
    localStorage.removeItem(KEYS.ACCOUNT);
    localStorage.removeItem(KEYS.FAVORITES);
    localStorage.removeItem(KEYS.CACHE);
  }

  // ---------- Favoritos ----------
  // Estrutura: { live: {id: item}, movie: {id: item}, series: {id: item} }
  function getFavorites() {
    const raw = localStorage.getItem(KEYS.FAVORITES);
    if (!raw) return { live: {}, movie: {}, series: {} };
    try {
      const parsed = JSON.parse(raw);
      return {
        live: parsed.live || {},
        movie: parsed.movie || {},
        series: parsed.series || {},
      };
    } catch (e) {
      return { live: {}, movie: {}, series: {} };
    }
  }

  function saveFavorites(favs) {
    localStorage.setItem(KEYS.FAVORITES, JSON.stringify(favs));
  }

  function isFavorite(type, id) {
    const favs = getFavorites();
    return !!(favs[type] && favs[type][id]);
  }

  function toggleFavorite(type, item) {
    const favs = getFavorites();
    if (!favs[type]) favs[type] = {};
    const id = String(item.id);
    if (favs[type][id]) {
      delete favs[type][id];
    } else {
      favs[type][id] = item;
    }
    saveFavorites(favs);
    return !!favs[type][id];
  }

  // ---------- Cache simples de listas (evita rebaixar tudo a cada abertura) ----------
  function getCache() {
    const raw = localStorage.getItem(KEYS.CACHE);
    if (!raw) return {};
    try { return JSON.parse(raw); } catch (e) { return {}; }
  }

  function setCache(key, value) {
    const cache = getCache();
    cache[key] = { data: value, ts: Date.now() };
    try {
      localStorage.setItem(KEYS.CACHE, JSON.stringify(cache));
    } catch (e) {
      // Se estourar cota do localStorage, limpa cache antigo e tenta de novo
      localStorage.removeItem(KEYS.CACHE);
    }
  }

  function getCacheEntry(key, maxAgeMs) {
    const cache = getCache();
    const entry = cache[key];
    if (!entry) return null;
    if (maxAgeMs && Date.now() - entry.ts > maxAgeMs) return null;
    return entry.data;
  }

  function clearCache() {
    localStorage.removeItem(KEYS.CACHE);
  }

  return {
    saveAccount, getAccount, clearAccount, clearAll,
    getFavorites, saveFavorites, isFavorite, toggleFavorite,
    getCacheEntry, setCache, clearCache,
  };
})();
