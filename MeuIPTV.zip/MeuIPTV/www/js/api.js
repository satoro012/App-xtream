/**
 * api.js
 * Comunicação com a API Xtream Codes (player_api.php) do servidor
 * informado pelo próprio usuário no login. Nenhuma credencial é enviada
 * a servidores de terceiros — as chamadas vão direto para o servidor
 * que o usuário configurou.
 */

const XtreamAPI = (() => {
  let account = null; // { server, username, password }

  function configure(acc) {
    account = acc;
  }

  function baseParams() {
    return `username=${encodeURIComponent(account.username)}&password=${encodeURIComponent(account.password)}`;
  }

  function apiUrl(action, extra = '') {
    return `${account.server}/player_api.php?${baseParams()}${action ? `&action=${action}` : ''}${extra}`;
  }

  async function request(action, extra = '') {
    const url = apiUrl(action, extra);
    let response;
    try {
      response = await fetch(url, { method: 'GET' });
    } catch (e) {
      throw new Error('Não foi possível conectar ao servidor. Verifique o endereço e sua conexão.');
    }
    if (!response.ok) {
      throw new Error(`Servidor retornou erro (${response.status}).`);
    }
    let json;
    try {
      json = await response.json();
    } catch (e) {
      throw new Error('Resposta inválida do servidor.');
    }
    return json;
  }

  // ---------- Autenticação ----------
  async function login() {
    const data = await request('');
    const auth = data && data.user_info;
    if (!auth || String(auth.auth) !== '1') {
      const msg = (auth && auth.status && auth.status !== 'Active')
        ? 'Sua conta não está ativa neste servidor.'
        : 'Usuário ou senha inválidos.';
      throw new Error(msg);
    }
    return {
      userInfo: auth,
      serverInfo: data.server_info || {},
    };
  }

  // ---------- Canais ao vivo ----------
  function getLiveCategories() { return request('get_live_categories'); }
  function getLiveStreams(categoryId) {
    return request('get_live_streams', categoryId ? `&category_id=${encodeURIComponent(categoryId)}` : '');
  }
  function liveStreamUrl(streamId, ext = 'm3u8') {
    return `${account.server}/live/${encodeURIComponent(account.username)}/${encodeURIComponent(account.password)}/${streamId}.${ext}`;
  }

  // ---------- Filmes (VOD) ----------
  function getVodCategories() { return request('get_vod_categories'); }
  function getVodStreams(categoryId) {
    return request('get_vod_streams', categoryId ? `&category_id=${encodeURIComponent(categoryId)}` : '');
  }
  function vodStreamUrl(streamId, ext = 'mp4') {
    return `${account.server}/movie/${encodeURIComponent(account.username)}/${encodeURIComponent(account.password)}/${streamId}.${ext}`;
  }

  // ---------- Séries ----------
  function getSeriesCategories() { return request('get_series_categories'); }
  function getSeries(categoryId) {
    return request('get_series', categoryId ? `&category_id=${encodeURIComponent(categoryId)}` : '');
  }
  function getSeriesInfo(seriesId) {
    return request('get_series_info', `&series_id=${encodeURIComponent(seriesId)}`);
  }
  function seriesEpisodeUrl(episodeId, ext = 'mp4') {
    return `${account.server}/series/${encodeURIComponent(account.username)}/${encodeURIComponent(account.password)}/${episodeId}.${ext}`;
  }

  return {
    configure,
    login,
    getLiveCategories, getLiveStreams, liveStreamUrl,
    getVodCategories, getVodStreams, vodStreamUrl,
    getSeriesCategories, getSeries, getSeriesInfo, seriesEpisodeUrl,
  };
})();
