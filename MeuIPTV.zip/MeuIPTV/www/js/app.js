/**
 * app.js
 * Orquestra a interface do MeuIPTV: login, navegação entre abas,
 * listagem de canais/filmes/séries, favoritos, pesquisa e ajustes.
 */

const App = (() => {
  const APP_VERSION = '1.0.0';
  const CACHE_TTL = 6 * 60 * 60 * 1000; // 6 horas

  let state = {
    tab: 'live', // live | movie | series | favorites
    categories: { live: [], movie: [], series: [] },
    streams: { live: [], movie: [], series: [] }, // lista completa da categoria atual
    selectedCategory: { live: null, movie: null, series: null },
    allLoaded: { live: false, movie: false, series: false }, // já buscou tudo (p/ pesquisa global)
    allStreams: { live: [], movie: [], series: [] },
    searchActive: false,
    currentSeries: null,
  };

  // ---------------------------------------------------------------
  // Utilidades de tela
  // ---------------------------------------------------------------
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
  }

  function setLoading(show) {
    document.getElementById('loading').classList.toggle('hidden', !show);
    if (show) document.getElementById('empty-state').classList.add('hidden');
  }

  function setEmpty(show) {
    document.getElementById('empty-state').classList.toggle('hidden', !show);
  }

  // ---------------------------------------------------------------
  // LOGIN
  // ---------------------------------------------------------------
  function initLogin() {
    const saved = Storage.getAccount();
    if (saved) {
      document.getElementById('input-server').value = saved.server;
      document.getElementById('input-username').value = saved.username;
      document.getElementById('input-password').value = saved.password;
      attemptLogin(saved, false);
    }

    document.getElementById('form-login').addEventListener('submit', (e) => {
      e.preventDefault();
      const server = document.getElementById('input-server').value.trim();
      const username = document.getElementById('input-username').value.trim();
      const password = document.getElementById('input-password').value;
      const remember = document.getElementById('input-remember').checked;

      if (!/^https?:\/\//i.test(server)) {
        showLoginError('O servidor deve começar com http:// ou https://');
        return;
      }
      attemptLogin({ server, username, password }, true, remember);
    });
  }

  function showLoginError(msg) {
    const el = document.getElementById('login-error');
    el.textContent = msg;
    el.classList.remove('hidden');
  }

  function setLoginBusy(busy) {
    document.getElementById('btn-login').disabled = busy;
    document.querySelector('#btn-login .btn-text').classList.toggle('hidden', busy);
    document.querySelector('#btn-login .btn-spinner').classList.toggle('hidden', !busy);
  }

  async function attemptLogin(account, showErrors, remember) {
    setLoginBusy(true);
    document.getElementById('login-error').classList.add('hidden');
    XtreamAPI.configure(account);
    try {
      const result = await XtreamAPI.login();
      if (remember !== false) Storage.saveAccount(account);
      state.userInfo = result.userInfo;
      onLoginSuccess();
    } catch (err) {
      setLoginBusy(false);
      if (showErrors !== false) showLoginError(err.message || 'Falha ao entrar. Tente novamente.');
    }
  }

  function onLoginSuccess() {
    setLoginBusy(false);
    showScreen('screen-app');
    loadTab('live');
  }

  // ---------------------------------------------------------------
  // NAVEGAÇÃO PRINCIPAL
  // ---------------------------------------------------------------
  function initNav() {
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        if (tab === 'settings') {
          openSettings();
          return;
        }
        document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        loadTab(tab);
      });
    });

    document.getElementById('btn-search').addEventListener('click', openSearch);
    document.getElementById('btn-search-close').addEventListener('click', closeSearch);
    document.getElementById('input-search').addEventListener('input', onSearchInput);
  }

  const TAB_TITLES = { live: 'Canais', movie: 'Filmes', series: 'Séries', favorites: 'Favoritos' };

  async function loadTab(tab) {
    state.tab = tab;
    state.searchActive = false;
    closeSearch(false);
    document.getElementById('header-title').textContent = TAB_TITLES[tab];
    document.getElementById('grid').innerHTML = '';
    setEmpty(false);

    if (tab === 'favorites') {
      document.getElementById('category-bar').innerHTML = '';
      renderFavorites();
      return;
    }

    setLoading(true);
    try {
      if (state.categories[tab].length === 0) {
        state.categories[tab] = await fetchCategories(tab);
      }
      renderCategoryBar(tab);
      const catId = state.selectedCategory[tab] || (state.categories[tab][0] && state.categories[tab][0].category_id) || null;
      state.selectedCategory[tab] = catId;
      await loadStreamsForCategory(tab, catId);
    } catch (err) {
      setLoading(false);
      setEmpty(true);
      document.getElementById('empty-state').querySelector('p').textContent =
        'Erro ao carregar conteúdo: ' + (err.message || 'tente novamente.');
    }
  }

  function fetchCategories(tab) {
    const cacheKey = `cats_${tab}`;
    const cached = Storage.getCacheEntry(cacheKey, CACHE_TTL);
    if (cached) return Promise.resolve(cached);

    const fn = tab === 'live' ? XtreamAPI.getLiveCategories
      : tab === 'movie' ? XtreamAPI.getVodCategories
      : XtreamAPI.getSeriesCategories;

    return fn().then(list => {
      const safe = Array.isArray(list) ? list : [];
      Storage.setCache(cacheKey, safe);
      return safe;
    });
  }

  function fetchStreams(tab, categoryId) {
    const fn = tab === 'live' ? XtreamAPI.getLiveStreams
      : tab === 'movie' ? XtreamAPI.getVodStreams
      : XtreamAPI.getSeries;
    return fn(categoryId).then(list => Array.isArray(list) ? list : []);
  }

  async function loadStreamsForCategory(tab, categoryId) {
    setLoading(true);
    setEmpty(false);
    try {
      const items = await fetchStreams(tab, categoryId);
      state.streams[tab] = items;
      setLoading(false);
      renderGrid(items, tab);
    } catch (err) {
      setLoading(false);
      setEmpty(true);
      document.getElementById('empty-state').querySelector('p').textContent =
        'Erro ao carregar itens: ' + (err.message || '');
    }
  }

  function renderCategoryBar(tab) {
    const bar = document.getElementById('category-bar');
    bar.innerHTML = '';
    state.categories[tab].forEach(cat => {
      const chip = document.createElement('button');
      chip.className = 'category-chip' + (cat.category_id === state.selectedCategory[tab] ? ' active' : '');
      chip.textContent = cat.category_name || 'Categoria';
      chip.addEventListener('click', () => {
        state.selectedCategory[tab] = cat.category_id;
        bar.querySelectorAll('.category-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        loadStreamsForCategory(tab, cat.category_id);
      });
      bar.appendChild(chip);
    });
  }

  // ---------------------------------------------------------------
  // GRID DE CARDS
  // ---------------------------------------------------------------
  function renderGrid(items, tab) {
    const grid = document.getElementById('grid');
    grid.innerHTML = '';
    setEmpty(items.length === 0);
    items.forEach(item => grid.appendChild(buildCard(item, tab)));
  }

  function buildCard(item, tab) {
    const card = document.createElement('div');
    card.className = 'card' + (tab === 'live' ? ' channel-card' : '');

    const poster = document.createElement('div');
    poster.className = 'card-poster';
    const imgUrl = tab === 'live' ? item.stream_icon : (item.stream_icon || item.cover);
    if (imgUrl) {
      const img = document.createElement('img');
      img.src = imgUrl;
      img.loading = 'lazy';
      img.onerror = () => { poster.innerHTML = '<span class="fallback-icon">' + iconFor(tab) + '</span>'; };
      poster.appendChild(img);
    } else {
      poster.innerHTML = '<span class="fallback-icon">' + iconFor(tab) + '</span>';
    }

    const favBtn = document.createElement('button');
    favBtn.className = 'card-fav-btn';
    const favId = item.stream_id || item.series_id;
    favBtn.classList.toggle('active', Storage.isFavorite(tab, favId));
    favBtn.textContent = '★';
    favBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isFav = Storage.toggleFavorite(tab, normalizeItem(item, tab));
      favBtn.classList.toggle('active', isFav);
      if (state.tab === 'favorites') renderFavorites();
    });

    const title = document.createElement('div');
    title.className = 'card-title';
    title.textContent = item.name || 'Sem nome';

    poster.appendChild(favBtn);
    card.appendChild(poster);
    card.appendChild(title);

    card.addEventListener('click', () => onCardClick(item, tab));
    return card;
  }

  function iconFor(tab) {
    return tab === 'live' ? '📺' : tab === 'movie' ? '🎬' : '📀';
  }

  function normalizeItem(item, tab) {
    // Guarda só os campos necessários para reexibir nos favoritos
    return {
      id: item.stream_id || item.series_id,
      name: item.name,
      stream_icon: item.stream_icon,
      cover: item.cover,
      container_extension: item.container_extension,
      plot: item.plot,
    };
  }

  function onCardClick(item, tab) {
    if (tab === 'live') {
      const ext = item.container_extension || 'm3u8';
      Player.open(XtreamAPI.liveStreamUrl(item.stream_id, ext), item.name, () => showScreen('screen-app'));
      showScreen('screen-player');
    } else if (tab === 'movie') {
      const ext = item.container_extension || 'mp4';
      Player.open(XtreamAPI.vodStreamUrl(item.stream_id, ext), item.name, () => showScreen('screen-app'));
      showScreen('screen-player');
    } else if (tab === 'series') {
      openSeriesDetail(item);
    }
  }

  // ---------------------------------------------------------------
  // FAVORITOS
  // ---------------------------------------------------------------
  function renderFavorites() {
    const favs = Storage.getFavorites();
    const grid = document.getElementById('grid');
    grid.innerHTML = '';
    const all = [
      ...Object.values(favs.live).map(i => ({ item: i, tab: 'live' })),
      ...Object.values(favs.movie).map(i => ({ item: i, tab: 'movie' })),
      ...Object.values(favs.series).map(i => ({ item: i, tab: 'series' })),
    ];
    setEmpty(all.length === 0);
    all.forEach(({ item, tab }) => {
      const fakeItem = { ...item, stream_id: item.id, series_id: item.id };
      grid.appendChild(buildCard(fakeItem, tab));
    });
  }

  // ---------------------------------------------------------------
  // SÉRIES — detalhe / temporadas / episódios
  // ---------------------------------------------------------------
  async function openSeriesDetail(item) {
    showScreen('screen-series-detail');
    document.getElementById('series-detail-title').textContent = item.name || 'Série';
    document.getElementById('series-detail-name').textContent = item.name || '';
    document.getElementById('series-detail-poster').src = item.stream_icon || item.cover || '';
    document.getElementById('series-detail-plot').textContent = 'Carregando informações...';
    document.getElementById('season-tabs').innerHTML = '';
    document.getElementById('episode-list').innerHTML = '';

    try {
      const info = await XtreamAPI.getSeriesInfo(item.series_id);
      state.currentSeries = info;
      const plot = (info.info && info.info.plot) || '';
      document.getElementById('series-detail-plot').textContent = plot || 'Sem descrição disponível.';

      const seasons = info.episodes ? Object.keys(info.episodes) : [];
      const tabsEl = document.getElementById('season-tabs');
      tabsEl.innerHTML = '';
      seasons.forEach((season, idx) => {
        const chip = document.createElement('button');
        chip.className = 'category-chip' + (idx === 0 ? ' active' : '');
        chip.textContent = 'Temporada ' + season;
        chip.addEventListener('click', () => {
          tabsEl.querySelectorAll('.category-chip').forEach(c => c.classList.remove('active'));
          chip.classList.add('active');
          renderEpisodes(info.episodes[season], item.name);
        });
        tabsEl.appendChild(chip);
      });
      if (seasons.length) renderEpisodes(info.episodes[seasons[0]], item.name);
    } catch (err) {
      document.getElementById('series-detail-plot').textContent =
        'Erro ao carregar episódios: ' + (err.message || '');
    }
  }

  function renderEpisodes(episodes, seriesName) {
    const list = document.getElementById('episode-list');
    list.innerHTML = '';
    (episodes || []).forEach(ep => {
      const row = document.createElement('div');
      row.className = 'episode-item';
      row.innerHTML = `
        <span class="episode-num">${ep.episode_num}</span>
        <span class="episode-title">${ep.title || ('Episódio ' + ep.episode_num)}</span>
        <span class="icon-btn">▶</span>
      `;
      row.addEventListener('click', () => {
        const ext = (ep.container_extension || 'mp4');
        const title = `${seriesName} — E${ep.episode_num}`;
        Player.open(XtreamAPI.seriesEpisodeUrl(ep.id, ext), title, () => showScreen('screen-series-detail'));
        showScreen('screen-player');
      });
      list.appendChild(row);
    });
  }

  function initSeriesDetail() {
    document.getElementById('btn-series-back').addEventListener('click', () => showScreen('screen-app'));
  }

  // ---------------------------------------------------------------
  // PESQUISA GLOBAL
  // ---------------------------------------------------------------
  function openSearch() {
    state.searchActive = true;
    document.getElementById('search-bar').classList.remove('hidden');
    document.getElementById('category-bar').classList.add('hidden');
    document.getElementById('input-search').value = '';
    document.getElementById('input-search').focus();
    ensureAllLoadedForSearch();
  }

  function closeSearch(restoreGrid = true) {
    state.searchActive = false;
    document.getElementById('search-bar').classList.add('hidden');
    document.getElementById('category-bar').classList.remove('hidden');
    if (restoreGrid && state.tab !== 'favorites') {
      renderGrid(state.streams[state.tab] || [], state.tab);
    }
  }

  async function ensureAllLoadedForSearch() {
    const types = ['live', 'movie', 'series'];
    for (const t of types) {
      if (state.allLoaded[t]) continue;
      try {
        if (state.categories[t].length === 0) state.categories[t] = await fetchCategories(t);
        // Busca todos os itens (sem filtro de categoria) para permitir pesquisa global
        const all = await fetchStreams(t, null);
        state.allStreams[t] = all;
        state.allLoaded[t] = true;
      } catch (e) {
        state.allStreams[t] = state.allStreams[t] || [];
      }
    }
  }

  function onSearchInput(e) {
    const q = e.target.value.trim().toLowerCase();
    const grid = document.getElementById('grid');
    grid.innerHTML = '';
    if (!q) { setEmpty(false); return; }

    const results = [];
    ['live', 'movie', 'series'].forEach(t => {
      (state.allStreams[t] || []).forEach(item => {
        if ((item.name || '').toLowerCase().includes(q)) results.push({ item, tab: t });
      });
    });

    setEmpty(results.length === 0);
    results.slice(0, 200).forEach(({ item, tab }) => grid.appendChild(buildCard(item, tab)));
  }

  // ---------------------------------------------------------------
  // AJUSTES
  // ---------------------------------------------------------------
  function initSettings() {
    document.getElementById('btn-settings-back').addEventListener('click', () => showScreen('screen-app'));
    document.getElementById('btn-refresh-content').addEventListener('click', async () => {
      Storage.clearCache();
      state.categories = { live: [], movie: [], series: [] };
      state.allLoaded = { live: false, movie: false, series: false };
      showScreen('screen-app');
      await loadTab(state.tab);
    });
    document.getElementById('btn-logout').addEventListener('click', () => {
      Storage.clearAccount();
      location.reload();
    });
    document.getElementById('btn-clear-data').addEventListener('click', () => {
      if (confirm('Isso vai apagar sua conta, favoritos e cache salvos neste aparelho. Continuar?')) {
        Storage.clearAll();
        location.reload();
      }
    });
    document.getElementById('app-version-number').textContent = APP_VERSION;
  }

  function openSettings() {
    const account = Storage.getAccount();
    document.getElementById('settings-server').textContent = account ? account.server : '-';
    document.getElementById('settings-username').textContent = account ? account.username : '-';
    document.getElementById('settings-status').textContent =
      (state.userInfo && state.userInfo.status) || 'Ativo';
    const exp = state.userInfo && state.userInfo.exp_date;
    document.getElementById('settings-expires').textContent = exp
      ? new Date(exp * 1000).toLocaleDateString('pt-BR')
      : 'Não informado';
    showScreen('screen-settings');
  }

  // ---------------------------------------------------------------
  // INIT GERAL
  // ---------------------------------------------------------------
  function init() {
    Player.init();
    initLogin();
    initNav();
    initSeriesDetail();
    initSettings();
    document.getElementById('btn-back').addEventListener('click', () => showScreen('screen-app'));
  }

  return { init };
})();

document.addEventListener('DOMContentLoaded', App.init);
